## jquery.btnSwitch
[![NPM version](http://img.shields.io/npm/v/jquery-btnswitch.svg?style=flat)](https://www.npmjs.com/package/jquery-btnswitch)
[![npm](https://img.shields.io/npm/l/jquery-btnswitch.svg)](https://www.npmjs.com/package/jquery-btnswitch)
[![npm](https://img.shields.io/npm/dt/jquery-btnswitch.svg)](https://www.npmjs.com/package/jquery-btnswitch)

A simple way to create button switches

look for examples and details at: https://eman1986.github.io/jquery.btnSwitch/
